#!/bin/sh

# Load global variables
. ./env.sh

# Step 5: Validate Prometheus installation
echo -n "Checking if Prometheus user exists..."
id prometheus > /dev/null
[ $? == 0 ] && echo "passed" || echo "failed"

echo -n "Checking if Prometheus is installed..."
[ -f /usr/local/bin/prometheus ] && echo "passed" || echo "failed"
