#!/bin/sh

PROMETHEUS_VERSION=2.22.0
BASEDIR=$(pwd)/..
TMPDIR=${BASEDIR}/tmp
PROMETHEUS_URL=http://localhost:9090/graph