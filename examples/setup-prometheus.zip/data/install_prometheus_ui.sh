#!/bin/sh

# Load global variables
. ./env.sh

# Step 4: Move the consoles and console_libraries directories from prometheus-files to /etc/prometheus folder and change the ownership to prometheus user.
sudo cp -r ${TMPDIR}/prometheus-files/consoles /etc/prometheus
sudo cp -r  ${TMPDIR}/prometheus-files/console_libraries /etc/prometheus
sudo chown -R prometheus:prometheus /etc/prometheus/consoles
sudo chown -R prometheus:prometheus /etc/prometheus/console_libraries
