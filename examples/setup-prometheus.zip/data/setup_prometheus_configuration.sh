#!/bin/sh

# Load global variables
. ./env.sh

# Step 6: Setup Prometheus configuration
echo "Setup Prometheus configuration"

cat << END > prometheus.yml
global:
  scrape_interval: 10s

scrape_configs:
  - job_name: 'prometheus'
    scrape_interval: 5s
    static_configs:
      - targets: ['localhost:9090']
END

sudo mv prometheus.yml /etc/prometheus/prometheus.yml

sudo chown prometheus:prometheus /etc/prometheus/prometheus.yml
