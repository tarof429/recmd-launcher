#!/bin/sh

# Load global variables
. ./env.sh

# Step 2: Create a Prometheus user, required directories, and make Prometheus the user as the owner of those directories.
sudo useradd --no-create-home --shell /bin/false prometheus
sudo mkdir /etc/prometheus
sudo mkdir /var/lib/prometheus
sudo chown prometheus:prometheus /etc/prometheus
sudo chown prometheus:prometheus /var/lib/prometheus
