#!/bin/sh

# Load global variables
. ./env.sh

# Step 7: Setup Prometheus Service File
echo "Setup Prometheus Service File"

sudo cat << END > prometheus.service
[Unit]
Description=Prometheus
Wants=network-online.target
After=network-online.target

[Service]
User=prometheus
Group=prometheus
Type=simple
ExecStart=/usr/local/bin/prometheus \
    --config.file /etc/prometheus/prometheus.yml \
    --storage.tsdb.path /var/lib/prometheus/ \
    --web.console.templates=/etc/prometheus/consoles \
    --web.console.libraries=/etc/prometheus/console_libraries

[Install]
WantedBy=multi-user.target
END

sudo mv prometheus.service /etc/systemd/system/prometheus.service

# Reload the systemd service to register the prometheus service and start the prometheus service.
sudo systemctl daemon-reload
sudo systemctl start prometheus
sleep 1

# Check the prometheus service status using the following command.
sudo systemctl status prometheus
