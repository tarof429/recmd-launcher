#!/bin/sh

# Load global variables
. ./env.sh

# Step 1: Download the source using curl, untar it, and rename the extracted folder to prometheus-files.
echo "Downloading Prometheus to $TMPDIR"

rm -rf $TMPDIR

mkdir -p $TMPDIR
cd $TMPDIR
curl -LO https://github.com/prometheus/prometheus/releases/download/v${PROMETHEUS_VERSION}/prometheus-${PROMETHEUS_VERSION}.linux-amd64.tar.gz
tar -xzf prometheus-${PROMETHEUS_VERSION}.linux-amd64.tar.gz
mv prometheus-${PROMETHEUS_VERSION}.linux-amd64 prometheus-files
