#!/bin/sh

# Load global variables
. ./env.sh

# Step 3: Copy prometheus and promtool binary from prometheus-files folder to /usr/local/bin and change the ownership to prometheus user.
sudo cp ${TMPDIR}/prometheus-files/prometheus /usr/local/bin/
sudo cp  ${TMPDIR}/prometheus-files/promtool /usr/local/bin/
sudo chown prometheus:prometheus /usr/local/bin/prometheus
sudo chown prometheus:prometheus /usr/local/bin/promtool
