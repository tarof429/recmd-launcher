#!/bin/sh

./recmd add -c "sh ./download_prometheus.sh" -d "Download Prometheus" -w "data"
./recmd add -c "sh ./install_prometheus.sh" -d "Install Prometheus" -w "data"
./recmd add -c "sh ./install_prometheus_ui.sh" -d "Install Prometheus UI" -w "data"
./recmd add -c "sh ./setup_prometheus.sh" -d "Setup Prometheus" -w "data"
./recmd add -c "sh ./validate_prometheus_installation.sh" -d "Validate Prometheus installation" -w "data"
./recmd add -c "sh ./setup_prometheus_configuration.sh" -d "Setup Prometheus Configuration" -w "data"
./recmd add -c "sh ./setup_prometheus_service_file.sh" -d "Setup Prometheus Service File" -w "data"
./recmd add -c "sh ./access_prometheus_web_ui.sh" -d "Access Prometheus Web UI" -w "data"
