#!/bin/sh

# Load global variables
. ./env.sh

# Step 8: Access Prometheus Web UI
echo "Access Prometheus Web UI"

curl $PROMETHEUS_URL

if [ $? != 0 ]; then
    echo "Unable to access Prometheus web UI at $PROMETHEUS_URL. Make sure port 9090 is open and try again."
else
    echo "Prometheus is successfully installed and accessible from $PROMETHEUS_URL"
fi
