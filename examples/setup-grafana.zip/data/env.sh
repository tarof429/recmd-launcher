#!/bin/sh

GRAFANA_VERSION=7.3.3

BASEDIR=$(pwd)/..
TMPDIR=${BASEDIR}/tmp
PROMETHEUS_URL=http://localhost:9090/graph
