#!/bin/sh

######################################################################
# Install grafana
######################################################################

# Load global variables
. ./env.sh

sudo rm -rf /usr/local//grafana-${GRAFANA_VERSION}

sudo cp -r ${TMPDIR}/grafana-${GRAFANA_VERSION} /usr/local

sudo ln -sf /usr/local/grafana-${GRAFANA_VERSION} /usr/local/grafana