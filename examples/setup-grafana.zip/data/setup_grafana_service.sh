#!/bin/sh

######################################################################
# Setup grafana service . This will create the grafana service. It should
# be performed after running setup_grafana.sh
######################################################################

# Load global variables
. ./env.sh

# Load variables for grafana
. ./grafana-server

# Setup Grafana Service File
echo "Setup Grafana Service File"

sudo cat << END > grafana.service
[Unit]
Description=Grafana
Wants=network-online.target
After=network-online.target

[Service]
User=${GRAFANA_USER}
Group=${GRAFANA_GROUP}
Type=simple
WorkingDirectory=/usr/local/grafana
ExecStart=/usr/local/grafana-${GRAFANA_VERSION}/bin/grafana-server \
    --config=${CONF_FILE}                                   \
    --pidfile=${PID_FILE_DIR}/grafana-server.pid            \
    cfg:default.paths.logs=${LOG_DIR}                       \
    cfg:default.paths.data=${DATA_DIR}                      \
    cfg:default.paths.plugins=${PLUGINS_DIR}                \
    cfg:default.paths.provisioning=${PROVISIONING_CFG_DIR}

LimitNOFILE=${MAX_OPEN_FILES}
TimeoutStopSec=20

[Install]
WantedBy=multi-user.target
END

sudo mv grafana.service /etc/systemd/system/grafana.service

# Reload the systemd service to register the grafana service and start the prometheus service.
sudo systemctl daemon-reload
sudo systemctl stop grafana
sudo systemctl start grafana
sleep 1

# Check the grafana service status using the following command.
sudo systemctl status grafana

curl http://localhost:3000 > /dev/null

if [ $? == 0 ]; then
    echo "Grafana is available at http://localhost:3000!"
else
    echo "Grafana could nto be accessed at http://localhost:3000"
fi
