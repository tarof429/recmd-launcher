#!/bin/sh

./recmd add -c "sh ./download_grafana.sh" -d "Download Grafana" -w "data"
./recmd add -c "sh ./install_grafana.sh" -d "Install Grafana" -w "data"
./recmd add -c "sh ./setup_grafana.sh" -d "Setup Grafana" -w "data"
./recmd add -c "sh ./setup_grafana_service.sh" -d "Setup Grafana service" -w "data"
