#!/bin/sh

# Load global variables
. ./env.sh

# Step 1: Download the source using curl, untar it, and rename the extracted folder to prometheus-files.
echo "Downloading Prometheus to $TMPDIR"

rm -rf $TMPDIR

mkdir -p $TMPDIR

cd $TMPDIR

wget https://dl.grafana.com/oss/release/grafana-${GRAFANA_VERSION}.linux-amd64.tar.gz
tar -zxvf grafana-${GRAFANA_VERSION}.linux-amd64.tar.gz
