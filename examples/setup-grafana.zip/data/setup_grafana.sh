#!/bin/sh

######################################################################
# Setup grafana. This will create the grafana user, install grafana, 
# and install configuration files and required directories
######################################################################

# Load global variables
. ./env.sh

# Load variables for grafana
. ./grafana-server

sudo useradd --no-create-home --shell /bin/false ${GRAFANA_USER}
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} /usr/local/grafana-${GRAFANA_VERSION}

# Creates default file (environment vars) to /etc/default/grafana-server
sudo cp grafana-server /etc/default/grafana-server
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} /etc/default/grafana-server

# Installs configuration file to /etc/grafana/grafana.ini
sudo mkdir -p /etc/grafana
sudo cp defaults.ini $CONF_FILE
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} /etc/grafana

# Create log dir
sudo mkdir -p $LOG_DIR
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} $LOG_DIR

# Create data dir
sudo mkdir -p $DATA_DIR
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} $DATA_DIR

# Create provisioning dir
sudo mkdir -p $PROVISIONING_CFG_DIR
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} $PROVISIONING_CFG_DIR

# Create PID file dir
sudo mkdir -p $PID_FILE_DIR
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} $PID_FILE_DIR

# Create plugins dir
sudo mkdir -p $PLUGINS_DIR
sudo chown -R ${GRAFANA_USER}:${GRAFANA_GROUP} $PLUGINS_DIR