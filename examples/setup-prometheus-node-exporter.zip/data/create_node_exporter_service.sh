#!/bin/sh

# Load global variables
. ./env.sh

sudo useradd -rs /bin/false node_exporter

cat << END > node_exporter.service
[Unit]
Description=Node Exporter
After=network.target

[Service]
User=node_exporter
Group=node_exporter
Type=simple
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=multi-user.target
END

sudo mv node_exporter.service /etc/systemd/system/node_exporter.service

# Reload the system daemon and star the node exporter service.
sudo systemctl daemon-reload
sudo systemctl start node_exporter
sleep 1

# check the node exporter status to make sure it is running in the active state.
sudo systemctl status node_exporter

# Enable the node exporter service to the system startup.
sudo systemctl enable node_exporter

echo "Access node_exporter metrics"

curl $NODE_EXPORTER_URL > /dev/null

if [ $? != 0 ]; then
    echo "Unable to access node_exporter at $NODE_EXPORTER_URL. Make sure port 9100 is open and try again."
else
    echo "node_exporter is successfully installed and accessible from $NODE_EXPORTER_URL"
fi
