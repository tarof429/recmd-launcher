#!/bin/sh

# Load global variables
. ./env.sh

echo "Downloading Node Exporter to $TMPDIR"

rm -rf $TMPDIR
mkdir -p $TMPDIR
cd $TMPDIR
curl -LO https://github.com/prometheus/node_exporter/releases/download/v${NODE_EXPORTER_VERSION}/node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz
tar -xzf node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz
sudo mv node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64/node_exporter /usr/local/bin

if [ -f /usr/local/bin/node_exporter ]; then
    echo "node_exporter successfully installed"
else
    echo "node_exporter was NOT installed under /usr/local/bin"
fi
