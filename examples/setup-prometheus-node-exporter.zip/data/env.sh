#!/bin/sh

NODE_EXPORTER_VERSION=0.18.1
BASEDIR=$(pwd)/..
TMPDIR=${BASEDIR}/tmp
NODE_EXPORTER_URL=http://localhost:9100/metrics